o zip "arvore" esta contido os .java das tarefa 1 e 2 da especifica��o "popula, carrega e salva"

o zip "tarefa1e2" esta todo o meu codigo de dicionario a arvore funcionando (ele e o meu src do projeto).
Basta voce apenas trocar os caminhos de leitura e a main que ira executar.

O arquivo que estou enviando esta com o meu nome completo para auxilia-lo na organiza��o dos trabalhos. Mas caso insista em que o nome da entrega seja "tarefa1e2" e s� tirar o zip correspondente nesta pasta

Optei em escolher o nome "tarefa1e2" porque eu fiz as 2 op��es (ja que a 1 era obrigatoria)