package _my_tools;

public class Comemora {
	public static final String msgSuc1 = 
	".d88888b  dP     dP  a88888b.  88888888b .d88888b  .d88888b   .88888.  " + "\n" + 
	"88.    \"' 88     88 d8'   `88  88        88.    \"' 88.    \"' d8'   `8b " + "\n" + 
	"`Y88888b. 88     88 88        a88aaaa    `Y88888b. `Y88888b. 88     88 " + "\n" + 
	"      `8b 88     88 88         88              `8b       `8b 88     88 " + "\n" + 
	"d8'   .8P Y8.   .8P Y8.   .88  88        d8'   .8P d8'   .8P Y8.   .8P " + "\n" + 
	" Y88888P  `Y88888P'  Y88888P'  88888888P  Y88888P   Y88888P   `8888P'  " + "\n" + 
	"ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo" + "\n" + 
	"                                                                       ";
	
	public static final String msgSuc2 = 
	".d88888b  dP     dP  a88888b.  88888888b .d88888b  .d88888b   .88888.  dP dP "  + "\n" + 
	"88.    \"' 88     88 d8'   `88  88        88.    \"' 88.    \"' d8'   `8b 88 88 "  + "\n" + 
	"`Y88888b. 88     88 88        a88aaaa    `Y88888b. `Y88888b. 88     88 88 88 "  + "\n" + 
	"      `8b 88     88 88         88              `8b       `8b 88     88 dP dP "  + "\n" + 
	"d8'   .8P Y8.   .8P Y8.   .88  88        d8'   .8P d8'   .8P Y8.   .8P       "  + "\n" + 
	" Y88888P  `Y88888P'  Y88888P'  88888888P  Y88888P   Y88888P   `8888P'  oo oo "  + "\n" + 
	"ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo";
} /* fim de Comemora */
